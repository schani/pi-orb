import type { ParentSnapshot } from "#src/lifecycle/parent-snapshot";
import type { AgentSpawnConfig } from "#src/lifecycle/subagent-manager";
import { renderSpawnNotes, textResult } from "#src/tools/helpers";
import type { ResolvedSpawnConfig } from "#src/tools/spawn-config";
import type { ParentSessionInfo, Subagent } from "#src/types";
import type { AgentDetails } from "#src/ui/display";

/** Narrow manager interface for the background spawner. */
export interface BackgroundManagerDeps {
  spawn(snapshot: ParentSnapshot, type: string, prompt: string, opts: AgentSpawnConfig): string;
  getRecord(id: string): Subagent | undefined;
}

/** All values the background spawner needs beyond the resolved config. */
export interface BackgroundParams {
  config: ResolvedSpawnConfig;
  snapshot: ParentSnapshot;
  parentSession: ParentSessionInfo;
  settings: { readonly maxConcurrent: number };
}

/**
 * Spawn a background agent and return the tool result immediately.
 * Owns: launch message formatting.
 */
export function spawnBackground(
  manager: BackgroundManagerDeps,
  params: BackgroundParams,
) {
  const { identity, execution, presentation, notes } = params.config;

  let id: string;
  try {
    id = manager.spawn(params.snapshot, identity.subagentType, execution.prompt, {
      parentSession: params.parentSession,
      description: execution.description,
      model: execution.model,
      requestedModel: execution.requestedModel,
      maxTurns: execution.effectiveMaxTurns,
      inheritContext: execution.inheritContext,
      thinkingLevel: execution.thinking,
      // resolveSpawnConfig already merged the agent's frontmatter and AgentTool
      // routed here on the result, so this door has committed.
      background: { kind: "explicit", isBackground: true },
    });
  } catch (err) {
    return textResult(err instanceof Error ? err.message : String(err));
  }

  const record = manager.getRecord(id);

  const isQueued = record?.status === "queued";
  // Annotated rather than inlined into the call: `textResult` is generic over its
  // details, so an inline literal would define the type instead of being checked
  // against it.
  const details: AgentDetails = {
    ...presentation.detailBase,
    toolUses: 0,
    tokens: "",
    durationMs: 0,
    status: "background",
    agentId: id,
  };
  return textResult(
    renderSpawnNotes(notes) +
      `Agent ${isQueued ? "queued" : "started"} in background.\n` +
      `Agent ID: ${id}\n` +
      `Type: ${identity.displayName}\n` +
      `Description: ${execution.description}\n` +
      (record?.outputFile ? `Output file: ${record.outputFile}\n` : "") +
      (isQueued
        ? `Position: queued (max ${params.settings.maxConcurrent} concurrent)\n`
        : "") +
      `\nYou will be notified when this agent completes.\n` +
      `Use get_subagent_result to retrieve full results, or steer_subagent to send it messages.\n` +
      `Do not duplicate this agent's work.`,
    details,
  );
}
